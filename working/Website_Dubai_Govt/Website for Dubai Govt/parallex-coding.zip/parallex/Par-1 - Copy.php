<!DOCTYPE html>
<!-- saved from url=(0027)http://www.sullivannyc.com/ -->
<html lang="en"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  <!-- (gs)  -->
  
  <title></title>
  <meta name="description" content="We are a multi-disciplinary brand engagement firm dedicated to connecting customers to brands at the very moments they’re likely to make decisions">     
   
  <!--[if lte IE 8]>
  <link rel="stylesheet" type="text/css" media="screen" href="/assets/css/explorer.css" />
  <script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>             
  <![endif]-->

<script type="text/javascript" async="" src="Clouds2_files/ga.js"></script>

 
        
  
   
  
  <link rel="stylesheet" type="text/css" media="screen" href="./Par-1_files/00000000006982a6a10fdf25cd942ded921e8277a8.css">
  <link rel="stylesheet" type="text/css" media="screen" href="./Par-1_files/global.css">
  
  
    
    <style type="text/css" media="screen">
      
        
        #case_studies #cs_nyu-stern {
          background-image: url(Par-1_files/firstBG.jpg);
        }
		
        #case_studies #cs_nyu-stern .contentWrapper2 {
          background-image: url(Par-1_files/sheikh_mohammed.png);
	
        }
     
        
        #case_studies #cs_cq_roll_call {
          background-image: url(Par-1_files/secondBG.jpg);
        }
		
		
        #case_studies #cs_cq_roll_call .contentWrapper {
          background-image: url(http://assets.sullivannyc.com/img/uploads/cs_0002_logo_2.png);
        }
        #case_studies #cs_cq_roll_call .abstract {
          margin-left: 370px;
        }
        
        #case_studies #cs_human-rights-watch {
          background-image: url(http://assets.sullivannyc.com/img/uploads/Sullivan_FG_00_Bkgd_HRW_1.jpg);
        }
        #case_studies #cs_human-rights-watch .contentWrapper {
          background-image: url(http://assets.sullivannyc.com/img/uploads/Sullivan_FG_00_Banner_HRW_NewLogo3.png);
        }
        #case_studies #cs_human-rights-watch .abstract {
          margin-left: 50px;
        }
        
        #case_studies #cs_discover-ready {
          background-image: url(http://assets.sullivannyc.com/img/uploads/cs_0004_2.jpg);
        }
        #case_studies #cs_discover-ready .contentWrapper {
          background-image: url(http://assets.sullivannyc.com/img/uploads/cs_0004_logo_2.png);
        }
        #case_studies #cs_discover-ready .abstract {
          margin-left: 240px;
        }
        
        #case_studies #cs_schwab {
          background-image: url(http://assets.sullivannyc.com/img/uploads/Schwab_Home_artwork.jpg);
        }
        #case_studies #cs_schwab .contentWrapper {
          background-image: url(http://assets.sullivannyc.com/img/uploads/Schwab_Home_logo21.png);
        }
        #case_studies #cs_schwab .abstract {
          margin-left: 340px;
        }
        
      
    </style>
               
  
  


  
  
  
  
  
  

  
  
  
   
  <script type="text/javascript" async="" src="./Par-1_files/ga.js"></script><script type="text/javascript" src="./Par-1_files/0000000000bf627e802336b06afc05befc32ea2740.js"></script>
  <script type="text/javascript" src="./Par-1_files/global.js"></script>
  
  


  
  
  <script type="text/javascript">
    Suli.twitter_user = "sullivannyc";
	
	function started() {
	document.getElementById('frame1').height=window.innerHeight;
	}
  </script>
  


  
  
  
  <script type="text/javascript">
    $(document).ready(function () {Suli.init("home");});
  </script>
      
  <!-- RSS  -->
  <link rel="alternate" type="application/rss+xml" title="Sullivan NYC Blog Feed" href="http://www.sullivannyc.com/blog/rss"> 
  <link rel="alternate" type="application/rss+xml" title="Job Openings at Sullivan NYC" href="http://www.sullivannyc.com/careers/rss">
</head>



  

<body class="home" onLoad="started()">



<!-- ClickTale Top part -->
<script type="text/javascript">
var WRInitTime=(new Date()).getTime();
</script>





<!-- ClickTale end of Top part --><!-- /header.global -->
<section id="page">





    <div id="message" style="margin-top: 0px; display: block;">
      <div class="contentWrapper">
      
      
      
      
        <p><img src="Par-1_files/text.png" width="500" height="59" alt=" "></p>
      </div>
    </div><!-- /#message -->
<div id="cs_nav" style="margin-top: 0px; position: fixed;"><ul><li class="case current" style="display: list-item;"><a href="http://www.sullivannyc.com/#cs_nyu-stern">Case Study Title</a></li><li class="case" style="display: list-item;"><a href="http://www.sullivannyc.com/#cs_cq_roll_call">Case Study Title</a></li><li class="case" style="display: list-item;"><a href="http://www.sullivannyc.com/#cs_human-rights-watch">Case Study Title</a></li><li class="case" style="display: list-item;"><a href="http://www.sullivannyc.com/#cs_discover-ready">Case Study Title</a></li><li class="case" style="display: list-item;"><a href="http://www.sullivannyc.com/#cs_schwab">Case Study Title</a></li></ul></div>


<div id="case_studies" style="height: 3180px;">







        
          <section id="cs_nyu-stern" style="height: 636px; display: block; width: 100%; background-position: 50% -181px;">
            <div class="contentWrapper2 innerScroll" style="height: 636px; background-position: 50% -181px; position:relative; z-index:1;">
              <div class="abstract" style="margin-top: 0px; width:100%; height:130px;">
  
              </div>
            </div>
          
             


       
       <iframe id="frame1" style="width:100%; height:100%; position:absolute; top:0px; left:0px; z-index:0" src="Clouds2.htm"></iframe>
         
         
    
          
          
  
          
          </section>
        
          <section id="cs_cq_roll_call" style="height: 636px; display: block; width: 100%; background-position: 50% -117px;">
            <div class="contentWrapper innerScroll" style="height: 636px; background-position: 50% -245px;">
              <div class="abstract" style="margin-top: 118px; margin-left:100px;">
        
       


<iframe src="http://localhost/parallex/file.php" style="width:100%; height:100%;"> </iframe>


        
        
              </div>
            </div>
          </section>
        
          <section id="cs_human-rights-watch" style="height: 636px; display: block; width: 100%; background-position: 50% -54px;">
            <div class="contentWrapper innerScroll" style="height: 636px; background-position: 50% -308px;">
              <div class="abstract" style="margin-top: 418px;">
                <header>
                  
                    <h2>
	turn the complex&nbsp;<em class="sc">into</em>&nbsp;<strong>the compelling</strong></h2>

                  
                </header>
                <div class="body">
                  <p>
	We created a communications platform that immediately connected the value of HRW's complex work to donors.&nbsp;</p>

                  
                  <a href="http://www.sullivannyc.com/casestudy/human-rights-watch/" class="more">Learn More</a>
                  
                </div> 
              </div>
            </div>
          </section>
        
          <section id="cs_discover-ready" style="height: 636px; display: block; width: 100%; background-position: 50% 10px;">
            <div class="contentWrapper innerScroll" style="height: 636px; background-position: 50% -372px;">
              <div class="abstract" style="margin-top: 418px;">
                <header>
                  
                    <h2>
	breathe life <em class="sc">into</em> <strong>business</strong></h2>

                  
                </header>
                <div class="body">
                  <p>
	A professional services firm that caters to large corporations differentiated themselves by talking to people like people.</p>

                  
                  <a href="http://www.sullivannyc.com/casestudy/discover-ready/" class="more">Learn More</a>
                  
                </div> 
              </div>
            </div>
          </section>
        
          <section id="cs_schwab" style="height: 636px; display: block; width: 100%; background-position: 50% 73px;">
            <div class="contentWrapper innerScroll" style="height: 636px; background-position: 50% -435px;">
              <div class="abstract" style="margin-top: 418px;">
                <header>
                  
                    <h2>
	convert decisions<em class="sc">&nbsp;into</em> <strong>action</strong></h2>

                  
                </header>
                <div class="body">
                  <p>
	Convincing financial advisors to go independent is just the beginning. Showing them how to get there takes a plan.</p>

                  
                  <a href="http://www.sullivannyc.com/casestudy/schwab/" class="more">Learn More</a>
                  
                </div> 
              </div>
            </div>
          </section>
      </div>  
    </div><!-- /#case_studies --> 
  
  
  <aside id="secondary_content">
    
    <section id="recent_content" class="clear" style="display: block;">
  <div class="contentWrapper clear">
    <section id="twitter_feed">
      <header class="local_header"><span class="ico"></span>
        <a href="http://www.twitter.com/sullivannyc" class="more">Follow Us</a>
      </header>
      <div class="body">
        <span class="loadstatus">Sorry, but there seems to be a problem fetching our most recent tweets.</span>
      </div>
    </section><!--/#twitter_feed -->
    
    <section id="news_feed">
      <header class="local_header">
        <h2><a href="http://www.sullivannyc.com/blog/">blog/news</a></h2>
        <a href="http://www.sullivannyc.com/blog/" class="more">Visit Blog</a>
      </header>
      <div class="body">
        <ul class="grid list">
          
          <li class="first">
            <span class="date">Posted on: Nov, 07 2012</span>
            <h3><a href="http://www.sullivannyc.com/blog/from-a-red-or-blue-state-what-matter-to-investors-this-election-season-is-g/" title="From a Red or Blue State? What Matter to Investors This Election Season is Green">From a Red or Blue State? What Matter to Investors This Election Season is Green</a></h3>
            <a href="http://www.sullivannyc.com/blog/from-a-red-or-blue-state-what-matter-to-investors-this-election-season-is-g/" class="more">Read More</a>
                                           
                <cite class="byline">Posted by: <a href="http://www.sullivannyc.com/people/barbara-apple-sullivan">Barbara Apple Sullivan</a></cite>
                
                                 
          </li>
          
          <li>
            <span class="date">Posted on: Nov, 05 2012</span>
            <h3><a href="http://www.sullivannyc.com/blog/is-volatility-hurting-or-helping-advisor-client-ties/" title="Is Volatility Hurting or Helping Advisor-Client Ties?">Is Volatility Hurting or Helping Advisor-Client Ties?</a></h3>
            <a href="http://www.sullivannyc.com/blog/is-volatility-hurting-or-helping-advisor-client-ties/" class="more">Read More</a>
                                           
                <cite class="byline">Posted by: <a href="http://www.sullivannyc.com/people/barbara-apple-sullivan">Barbara Apple Sullivan</a></cite>
                
                                 
          </li>
          
          <li>
            <span class="date">Posted on: Oct, 12 2012</span>
            <h3><a href="http://www.sullivannyc.com/blog/obama-romney-and-what-their-voices-tell-us/" title="Obama, Romney, and What Their Voices Tell Us">Obama, Romney, and What Their Voices Tell Us</a></h3>
            <a href="http://www.sullivannyc.com/blog/obama-romney-and-what-their-voices-tell-us/" class="more">Read More</a>
                                           
                <cite class="byline">Posted by: <a href="http://www.sullivannyc.com/people/barbara-apple-sullivan">Barbara Apple Sullivan</a></cite>
                
                                 
          </li>
          
          <li>
            <span class="date">Posted on: Sep, 28 2012</span>
            <h3><a href="http://www.sullivannyc.com/blog/obama-vs-romney-who-wins-in-terms-of-websites-that-is/" title="Obama vs. Romney - Who Wins…In Terms of Websites, That Is">Obama vs. Romney - Who Wins…In Terms of Websites, That Is</a></h3>
            <a href="http://www.sullivannyc.com/blog/obama-vs-romney-who-wins-in-terms-of-websites-that-is/" class="more">Read More</a>
                                           
                <cite class="byline">Posted by: <a href="http://www.sullivannyc.com/people/john">John</a></cite>
                
                                 
          </li>
          
          <li>
            <span class="date">Posted on: Sep, 12 2012</span>
            <h3><a href="http://www.sullivannyc.com/blog/communication-is-as-important-to-todays-investors-as-performance/" title="Communication is as important to today’s investors as performance">Communication is as important to today’s investors as performance</a></h3>
            <a href="http://www.sullivannyc.com/blog/communication-is-as-important-to-todays-investors-as-performance/" class="more">Read More</a>
                                           
                <cite class="byline">Posted by: <a href="http://www.sullivannyc.com/people/barbara-apple-sullivan">Barbara Apple Sullivan</a></cite>
                
                                 
          </li>
          
        </ul> 
      </div>
    </section><!-- /#news_feed -->
  
  </div>
</section><!-- /#recent_content -->                       
  </aside><!-- /#white_papers -->
     
</section><!-- /#page -->
<footer class="global" style="display: block;">
  <div class="contentWrapper">
    <div class="colWrap clear">
      <div class="clear col two">
        <h4>Locations</h4>
        <div class="col">
          
            <h5>New York</h5>
            <address>
              <span class="street-address">450 West 14th Street, 12th Floor</span><br>
              <span class="region">New York</span>, 
              <abbr class="locality" title="New York">NY</abbr> 
              <span class="postal-code">10014</span>
            </address>
            <ul>
                              <li><abbr title="Phone">p</abbr>. <span class="tel">212 888 2881</span></li>
                                            <li><abbr title="Fax">f</abbr>. <span class="tel">212 888 2766</span></li>
               
                              <li><abbr title="Email">e</abbr>. <a class="email" href="mailto:info@sullivannyc.com">info@sullivannyc.com</a></li>
                          </ul>
             
          
        </div>
        
        <div class="col end">
          
            <h5>Washington D.C.</h5>
            <address>
              <span class="street-address">1806 24th Street NW</span><br>
              <span class="region">Washington</span>, 
              <abbr class="locality" title="New York">DC</abbr> 
              <span class="postal-code">20008</span>
            </address>
            <ul>
                              <li><abbr title="Phone">p</abbr>. <span class="tel">202 667 2770</span></li>
                                            <li><abbr title="Fax">f</abbr>. <span class="tel">202 667 2771</span></li>
               
                          </ul>
             
          
        </div>
      </div>
      <div id="social" class="clear col two end">
        <h4>Follow Us</h4>
        <ul class="clear social_links">
          
            <li><a href="http://www.linkedin.com/company/sullivan" class="li">LinkedIn</a></li>
          
            <li><a href="http://twitter.com/#!/sullivannyc" class="tw">Twitter</a></li>
          
            <li><a href="http://www.facebook.com/pages/Sullivan/165770676800241" class="fb">Facebook</a></li>
          
            <li><a href="http://www.sullivannyc.com/blog/rss" class="rss">RSS</a></li>   
        </ul>
      </div>
    </div>
    <div id="copyright">
      <p>Copyright 2013 Sullivan &amp; Company</p>
      <a href="http://www.sullivannyc.com/client-login/" class="login">Client Login</a>
    </div>
  </div>
</footer><!-- /footer.global -->
<script type="text/javascript">
  // GA
  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-21272635-1']);
  _gaq.push(['_setDomainName', 'sullivannyc.com']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();

</script>
<!-- ClickTale Bottom part -->
<div id="ClickTaleDiv" style="display: none;"></div>
<script type="text/javascript">
if(document.location.protocol!='https:')
  document.write(unescape("%3Cscript%20src='http://s.clicktale.net/WRc3.js'%20type='text/javascript'%3E%3C/script%3E"));
</script><script src="./Par-1_files/WRc3.js" type="text/javascript"></script>
<script type="text/javascript">
if(typeof ClickTale=='function') ClickTale(13488,1,"www03");
</script>
<!-- ClickTale end of Bottom part -->


</body></html>