<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="eng" lang="eng">
<head>
    <meta http-equiv="content-type" content="text/html; charset=utf-8" />
    <title>Spritely 0.6 Examples</title>
    <meta name="keywords" content="" />    
    
    <style type="text/css">

        #bird {
	background: transparent url(images/bird.png) 0 0 no-repeat;
	position: absolute;
	top: 0px;
	left: 0px;
	width: 500px;
	height: 200px;
	z-index: 2000;
	cursor: pointer;
	overflow:auto;
        }
		
		
		
    </style>
    
    <!-- IE6 fixes are found in styles/ie6.css -->
    <!--[if lte IE 6]><link rel="stylesheet" type="text/css" href="styles/ie6.css" /><![endif]-->
    
<script src="scripts/jquery-1.6.3.min.js" type="text/javascript"></script>
    <script src="scripts/jquery.spritely-0.6.js" type="text/javascript"></script>

    <script type="text/javascript">

        (function($) {
            $(document).ready(function() {
              
            
                $('#bird')
                    .sprite({
                        fps: 10, 
                        no_of_frames: 42,
                        // the following are optional: new in version 0.6...
                        start_at_frame: 2,
                        on_first_frame: function(obj) {
                            if (window.console) {
                                console.log('first frame');
                            }
                        },
                        on_last_frame: function(obj) {
                            // you could stop the sprite here with, e.g.
                            // obj.spStop();
                            if (window.console) {
                                console.log('last frame');
                            }
                        },
                        on_frame: {
                            2: function(obj) {
                                // you could change the 'state' of the
                                // sprite here with, e.g. obj.spState(2);
                                if (window.console) {
                                    console.log('frame 2');
                                }
                            }
                        }
                    })
                    .spRandom({top: 0, bottom: 0, left: 0, right: 0})
                    .isDraggable()
                    .activeOnClick()
                    .active();
             
                
             
                
            });
        })(jQuery);
    
    </script>
</head>
<body>

<div id="bird"></div>


</body>
</html>
